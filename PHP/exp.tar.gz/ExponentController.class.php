<?php

namespace Home\Controller;
use Think\Controller;
use Hprose\Client;

/**
 * 指数还原
 */
class ExponentController extends MainController {
    // 插件最新版本号
    public $last_verson = '1.5.3';
    
    function __construct(){
        parent::__construct();
        $this->last_verson = get_last_version('58tu-sycm-Chrome73');
         
    }
    public function index(){
        if (IS_AJAX) {
            $exponent = I('get.exponent/s', '');//指数
            $type = I('get.type/s', '');//类型
            $data = [];
            if (empty($exponent) || empty($type)) {
                json_error('请正确填写指数数据。');
            }
            $exponent_arr = explode(',', $exponent);
            if ($type == 'jyzs') {
                $data = $this-> getAmount($exponent_arr);
            }
            if ($type == 'llzs' || $type == 'ssrq') {
                $data = $this-> getFlow($exponent_arr);
            }
            if ($type == 'zhlzs') {
                $data = $this-> getonversion($exponent_arr);
            }
            if ($type == 'kqzs') {
                $data = $this-> getUserNum($exponent_arr);
            }
            if ($type == 'gjcjyzs') {
                $data = $this-> getPayNum($exponent_arr);
            }
            json_exit($data);
        }
        
        #$title = "58图工具 - 生意参谋指数转化 自动计算 批量下载";
        $this->assign('title', $title);
        $this->assign('page_description','58图指数还原-生意参谋指数一键还原、自动计算、批量下载');
        $this->assign('last_verson',$this->last_verson);
        $this->display();
    }
    //交易指数 获取 预估成交金额
    private function getAmount($exponent){
        foreach ($exponent as $k => $v) {
            $v = intval($v);
            if ($v<2000) {
                $amount = 0.00245*pow($v,1.60068);
            }else if ($v<10000) {
                $amount = 0.0014*pow($v,1.6752);
            }else if ($v<30000) {
                $amount = 0.00085*pow($v,1.72996);
            }else if ($v<300000) {
                $amount = 0.00054*pow($v,1.77376);
            }else if ($v<350000) {
                $amount = 0.00035*pow($v,1.80794);
            }else{
                $amount = 0.00034691*pow($v,1.80924012);
            }
            $data[$k] = intval($amount);
        }
        return $data;
    }
    //流量指数 获取 预估流量
    //搜索人气 获取 预估流量
    private function getFlow($exponent){
        foreach ($exponent as $k => $v) {
            $v = intval($v);
            if ($v<500) {
                $amount = 0.00427*pow($v,1.51077);
            }else if ($v<1500) {
                $amount = 0.00247*pow($v,1.59897);
            }else if ($v<5000) {
                $amount = 0.001588*pow($v,1.659102);
            }else if ($v<20000) {
                $amount = 0.001027*pow($v,1.710245);
            }else if ($v<80000) {
                $amount = 0.000663*pow($v,1.754609);
            }else{
                $amount = 0.000462*pow($v,1.786536);
            }
            $data[$k] = intval($amount);
        }
        return $data;
    }
    //转化率指数 获取 预估转化率
    private function getonversion($exponent){
        $v = intval($v);
        foreach ($exponent as $k => $v) {
            if ($v<500) {
                $amount = 0.0000001105*pow($v,1.9994006599);
            }else if ($v<900) {
                $amount = 0.0000001675*pow($v,1.9318764427);
            }else if ($v<1200) {
                $amount = 0.0000002429*pow($v,1.8773031503);
            }else if ($v<1500) {
                $amount = 0.0000003496*pow($v,1.8258839124);
            }else if ($v<1850) {
                $amount = 0.0000005311*pow($v,1.768679191);
            }else if ($v<2400) {
                $amount = 0.0000007821*pow($v,1.7172639687);
            }else{
                $amount = 0.0000016975*pow($v,1.617833172);
            }
            $data[$k] = round($amount,2);
        }
        return $data;
    }
    //客群指数 获取 预估购买人数
    private function getUserNum($exponent){
        $v = intval($v);
        foreach ($exponent as $k => $v) {
            if ($v<600) {
                $amount = 0.004006*pow($v,1.522933);
            }else if ($v<1200) {
                $amount = 0.002638*pow($v,1.589015);
            }else if ($v<4000) {
                $amount = 0.001743*pow($v,1.647171);
            }else if ($v<10000) {
                $amount = 0.001192*pow($v,1.693395);
            }else if ($v<20000) {
                $amount = 0.000906*pow($v,1.72343);
            }else{
                $amount = 0.00072*pow($v,1.746593);
            }
            $data[$k] = intval($amount);
        }
        return $data;
    }
    //关键词交易指数 获取预估支付件数
    private function getPayNum($exponent){
        $v = intval($v);
        foreach ($exponent as $k => $v) {
            if ($v<600) {
                $amount = 0.004006*pow($v,1.522933);
            }else if ($v<1200) {
                $amount = 0.002638*pow($v,1.589015);
            }else if ($v<4000) {
                $amount = 0.001743*pow($v,1.647171);
            }else if ($v<10000) {
                $amount = 0.001192*pow($v,1.693395);
            }else if ($v<20000) {
                $amount = 0.000906*pow($v,1.72343);
            }else{
                $amount = 0.00072*pow($v,1.746593);
            }
            $data[$k] = intval($amount);
        }
        return $data;
    }
    /**
     * 解密数据
     * 测试：http://www.58tu.com/Exponent/decode?data=1DD3F51271D71DE91DA4BB3B422F992F3038212C2C59C7C1502660F99ECE000444C5BC54678C18C01E11E4A780C2C524554C2BA360EB150687F473465B5730B4
     */
    public function decode(){

        $data = I('data/s', '');
        if(!$data){
            json_error('data is empyt');
        }
        $data = hex2bin($data);
        #var_dump($data);
        $key = 'w28Cz694s63kBYk4';
        $iv = '4kYBk36s496zC82w';
        $method = 'AES-128-CBC';
        $options = OPENSSL_RAW_DATA;
        $str = openssl_decrypt($data, $method, $key,  $options, $iv);
        $str = json_decode($str);
        
        $counter = session('last_decode_sycm');
        $need_log = false;
        $reset_counter = false;
        if (empty($counter)) {// 初始化
            $counter=['num'=>0, 'time'=>time()];
            $need_log = true;
        } 
        
        if ($counter['num'] >= 10) {
            $need_log = true;//连续访问超过10次 记录
            $reset_counter = true;
        }
        if ((time()-$counter['time']) > 10) {
            $need_log = true;//两次间隔超过10s 记录
        }
        if ($this->userid && $need_log) {
            $params = [
                'remark'=>'len:'.strlen($data).'; num:'.$counter['num'], #记录解密数据长度
                ];
            $_model = 'BrowserPlug';
            $id = 2;
            $msg = action_log('use_plug', $_model , $id, $this->userid, $params);
            #dump($msg);
        }
        if ($reset_counter) {
            $counter['num'] = 0;
        }
        
        $counter['num'] += 1;
        $counter['time'] = time();
        session('last_decode_sycm', $counter);
         
        $res = ['error'=>0, 'data'=>$str, 'has_login'=>$this->userid>0, 'log'=>$need_log];
        json_exit($res);
    }
    /**
     * 检查插件是否需要更新
     */
    public function checkupgrade()
    {
        $version = I('get.version');
        if (empty($version)) {
            json_error('version is empty!');
        }
        $need_upgrade = false;
        
        if ($version<$this->last_verson) {
            $need_upgrade = true;
        }
        
        $data = [
            'error'=>0,// 错误码
            
            'cur_versoin'=>$version, // 当前版本号
            'last_verson'=>$this->last_verson,// 最新版本号
            
            'cur_version'=>$version, // 当前版本好
            'last_version'=>$this->last_verson,// 最新版本号
            'need_upgrade'=>$need_upgrade,// 是否需要更新
            'message'=>'',// 提示信息直接展现给用户
            'url'=>'https://www.58tu.com/Exponent.html', // 若需要更新点击后跳转到这里
        ];
        json_exit($data);
    }
    public function status(){
        if ($this->userid) {
            $data = ['error'=>0, 'has_login'=>true, 
                'message'=>'已登录',
                'nickname'=>$this->userinfo['nickname'],
                ];
        } else {
            $data = ['error'=>1, 'has_login'=>false, 
                'message'=>'未授权',
                'subcode'=>'need.login',
                ];
        }
        json_exit($data);
    }
    public function gongnengyanshi(){
        $this->display();
    }
}